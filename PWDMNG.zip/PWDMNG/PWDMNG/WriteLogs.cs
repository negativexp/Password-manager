﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PWDMNG
{
    internal class WriteLogs
    {
        public static void Write(Exception e)
        {

        }
    }
}
